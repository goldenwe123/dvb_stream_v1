package com.example.socketclient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;



public class MainActivity extends AppCompatActivity {

    private static final int RTP_BUFFER_SIZE = 2000;

    private Thread thread;
    private Thread thread_rtp;
    private Socket clientSocket;
    private BufferedWriter bw;
    private BufferedReader br;
    private byte[] tmp = new byte[188];
    private TextView speedView;
    private Handler handler = new Handler();
    private float speed;

    byte[] bytes;
    byte[][] rtp_buffer = new byte[RTP_BUFFER_SIZE][200];
    int rtp_head = 0;
    int rtp_tail = 0;


    int rtpseq = 1;

    //UDP
    int port = 8888;            // port : 連接埠
    InetAddress server ;
    String msg;            // 欲傳送的訊息，每個 UdpClient 只能傳送一個訊息。



    public static String byte2hex(byte abyte) {
        StringBuilder result = new StringBuilder();
            result.append(String.format("%02x", abyte));
        return result.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        speedView  = (TextView) findViewById(R.id.textView);
        try {
            server =  InetAddress.getByName("127.0.0.1");
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        for(int i=0 ;i<RTP_BUFFER_SIZE;i++) {

            rtp_buffer[i][0x0] = (byte) 0x80;
            rtp_buffer[i][0x1] = (byte) 0x21;
            rtp_buffer[i][0x4] = (byte) 0x00; // }
            rtp_buffer[i][0x5] = (byte) 0x00; // } FIXME: should really be a valid stamp
            rtp_buffer[i][0x6] = (byte) 0x00; // }
            rtp_buffer[i][0x7] = (byte) 0x00; // }
            rtp_buffer[i][0x8] = (byte) 0x04;
            rtp_buffer[i][0x9] = (byte) 0x60;
            rtp_buffer[i][0xa] = (byte) 0x64;
            rtp_buffer[i][0xb] = (byte) 0x16;
        }

        thread=new Thread(Connection);
        thread.start();

        thread_rtp=new Thread(rtp_send);
        thread_rtp.start();

    }

    private Runnable Connection=new Runnable() {
        @Override
        public void run() {
        /*
            try {

                DatagramSocket socket = new DatagramSocket();
                DatagramPacket packet = new DatagramPacket(bytes, 200, server, port);

                while(true) {
                    for (int i = 0; i < 10000; i++) {
                        int p = i * 188;
                        rtp_buffer[2] = (byte)(rtpseq >> 8 );
                        rtp_buffer[3] = (byte)rtpseq;
                        rtpseq++;
                        System.arraycopy(bytes,p,rtp_buffer,0x0c,188);

                        packet = new DatagramPacket(rtp_buffer, 0, 200, server, port);

                        socket.send(packet);
                        Thread.sleep(31);
                    }

                }

            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            */



            try {
                InetAddress serverIp = InetAddress.getByName("114.33.82.82");
                int serverPort = 80;
                clientSocket = new Socket(serverIp, serverPort);
                bw = new BufferedWriter( new OutputStreamWriter(clientSocket.getOutputStream()));
               // br = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                InputStream is = clientSocket.getInputStream();


                float count = 0;
                long diff;
                long start_time = SystemClock.uptimeMillis();

                while (clientSocket.isConnected()) {


                    if(rtp_head == ((rtp_tail+1) % RTP_BUFFER_SIZE )) {
                        Log.d("Golden","RTP Buffer full");
                        continue;
                    }

                    rtp_buffer[rtp_tail][2] = (byte)(rtpseq >> 8 );
                    rtp_buffer[rtp_tail][3] = (byte)rtpseq;
                    rtpseq++;
                    int count_temp = 0;
                    int len = 0;

                    while(count_temp != 188) {
                        len = is.read(rtp_buffer[rtp_tail], count_temp+0x0c, 188-count_temp);
                        count_temp += len;
                    }

                    rtp_tail++;
                    rtp_tail %= RTP_BUFFER_SIZE;

                    //packet = new DatagramPacket( rtp_buffer[rtp_tail], 0, 200, server, port);
                    //socket.send(packet);

                    count +=  188;
                    long  end_time = SystemClock.uptimeMillis();
                    diff = end_time - start_time;

                    if(diff >= 1000 ) {
                        speed = count / 1024 / diff * 1000 * 8;
                        //Log.d("Golden","Speed: "+speed);
                        count = 0;
                        start_time = SystemClock.uptimeMillis();


                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                speedView.setText("Speed: "+speed);
                            }
                        });
                    }

                }


            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


        }

    };


    private Runnable rtp_send=new Runnable() {


        File sdcard = Environment.getExternalStorageDirectory();
        File file = new File(sdcard,"out.ts");

        public void run() {
            DatagramSocket socket = null;
            DatagramPacket packet ;

            FileOutputStream fos  = null;
            try {
                fos = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                Log.d("Golden","ERROR:"+e.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("Golden","ERROR:"+e.getMessage());
            }

            try {
                socket = new DatagramSocket();

                while(true) {

                    if(  rtp_head == rtp_tail ) {
                        continue;
                    }

                    //packet = new DatagramPacket( rtp_buffer[rtp_head], 0, 200, server, port);
                    //socket.send(packet);

                   // if(rtp_buffer[rtp_head][0x0c+2] != (byte)0xA2 ) {
                        //Log.d("Golden","ERROR:"+byte2hex(rtp_buffer[rtp_head][0x0c+2]));
                        //fos.write(rtp_buffer[rtp_head], 0x0c, 188);
                        packet = new DatagramPacket( rtp_buffer[rtp_head], 0, 200, server, port);
                        socket.send(packet);
                   //}


                    rtp_head++;
                    rtp_head %= RTP_BUFFER_SIZE;

                }


            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
    };


}
